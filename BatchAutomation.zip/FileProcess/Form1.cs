﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileProcess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnProcessJFIF_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtRootFolder.Text.Trim()))
            {
                MessageBox.Show("Provide root folder!", "Warning");
                return;
            }

            string[] files;

            if (chkAll.Checked)
                files = Directory.GetFiles(txtRootFolder.Text.Trim(), "*.*", SearchOption.AllDirectories);
            else
                files = Directory.GetFiles(txtRootFolder.Text.Trim());


            foreach (string file in files)
            {
                if (Path.GetExtension(file) == string.Empty && !Path.GetFileName(file).Contains("_"))
                {
                    byte[] by = File.ReadAllBytes(file);
                    File.WriteAllBytes(file, by.Skip(3).ToArray());
                    string oldFileName = Path.GetFileName(file);
                    System.IO.FileInfo fileInfo = new System.IO.FileInfo(file);
                    fileInfo.Rename(oldFileName + ".jpg", FileInfoExtensions.FileExistBehavior.Replace);
                }
            }


            if (chkDeleteExcept.Checked)
            {
                if (chkAll.Checked)
                    files = Directory.GetFiles(txtRootFolder.Text.Trim(), "*.*", SearchOption.AllDirectories);
                else
                    files = Directory.GetFiles(txtRootFolder.Text.Trim());

                foreach (string file in files)
                {
                    if (Path.GetExtension(file) != ".jpg" && Path.GetExtension(file) != ".pdf")
                    {
                        if (File.Exists(file))
                            File.Delete(file);
                    }
                }

            }
        }
    }
}

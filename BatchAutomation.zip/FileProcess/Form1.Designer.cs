﻿
namespace FileProcess
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtRootFolder = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnProcessJFIF = new System.Windows.Forms.Button();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.chkDeleteExcept = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // txtRootFolder
            // 
            this.txtRootFolder.Location = new System.Drawing.Point(139, 41);
            this.txtRootFolder.Name = "txtRootFolder";
            this.txtRootFolder.Size = new System.Drawing.Size(597, 26);
            this.txtRootFolder.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Root Path";
            // 
            // btnProcessJFIF
            // 
            this.btnProcessJFIF.Location = new System.Drawing.Point(35, 135);
            this.btnProcessJFIF.Name = "btnProcessJFIF";
            this.btnProcessJFIF.Size = new System.Drawing.Size(212, 40);
            this.btnProcessJFIF.TabIndex = 17;
            this.btnProcessJFIF.Text = "Process JFIF files";
            this.btnProcessJFIF.UseVisualStyleBackColor = true;
            this.btnProcessJFIF.Click += new System.EventHandler(this.btnProcessJFIF_Click);
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Location = new System.Drawing.Point(35, 95);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(165, 24);
            this.chkAll.TabIndex = 18;
            this.chkAll.Text = "All Sub Directories";
            this.chkAll.UseVisualStyleBackColor = true;
            // 
            // chkDeleteExcept
            // 
            this.chkDeleteExcept.AutoSize = true;
            this.chkDeleteExcept.Location = new System.Drawing.Point(268, 95);
            this.chkDeleteExcept.Name = "chkDeleteExcept";
            this.chkDeleteExcept.Size = new System.Drawing.Size(237, 24);
            this.chkDeleteExcept.TabIndex = 21;
            this.chkDeleteExcept.Text = "Delete files Except (.jpg,.pdf)";
            this.chkDeleteExcept.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 225);
            this.Controls.Add(this.chkDeleteExcept);
            this.Controls.Add(this.chkAll);
            this.Controls.Add(this.btnProcessJFIF);
            this.Controls.Add(this.txtRootFolder);
            this.Controls.Add(this.label5);
            this.Name = "Form1";
            this.Text = "File Process";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRootFolder;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnProcessJFIF;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.CheckBox chkDeleteExcept;
    }
}


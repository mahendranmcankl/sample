﻿
namespace MagAutomation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.btnDownload = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtHomeUrl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBookUrl = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFolderName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPageCount = new System.Windows.Forms.TextBox();
            this.lblFullProgress = new System.Windows.Forms.Label();
            this.lblBookProgress = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRootFolder = new System.Windows.Forms.TextBox();
            this.lstBooks = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblTotalBooks = new System.Windows.Forms.Label();
            this.btnImageDownload = new System.Windows.Forms.Button();
            this.chkAuto = new System.Windows.Forms.CheckBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(36, 31);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(212, 35);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnDownload
            // 
            this.btnDownload.Location = new System.Drawing.Point(27, 523);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(212, 35);
            this.btnDownload.TabIndex = 1;
            this.btnDownload.Text = "Start Download";
            this.btnDownload.UseVisualStyleBackColor = true;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(254, 523);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(212, 35);
            this.button3.TabIndex = 2;
            this.button3.Text = "Rename Folders";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtHomeUrl
            // 
            this.txtHomeUrl.Location = new System.Drawing.Point(275, 35);
            this.txtHomeUrl.Name = "txtHomeUrl";
            this.txtHomeUrl.Size = new System.Drawing.Size(571, 26);
            this.txtHomeUrl.TabIndex = 3;
            this.txtHomeUrl.Text = "https://www.magzter.com/";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Add Books List";
            // 
            // txtBookUrl
            // 
            this.txtBookUrl.Location = new System.Drawing.Point(351, 123);
            this.txtBookUrl.Name = "txtBookUrl";
            this.txtBookUrl.Size = new System.Drawing.Size(658, 26);
            this.txtBookUrl.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(198, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Book Home Page";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(198, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Folder Name";
            // 
            // txtFolderName
            // 
            this.txtFolderName.Location = new System.Drawing.Point(351, 166);
            this.txtFolderName.Name = "txtFolderName";
            this.txtFolderName.Size = new System.Drawing.Size(297, 26);
            this.txtFolderName.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(198, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "No of pages";
            // 
            // txtPageCount
            // 
            this.txtPageCount.Location = new System.Drawing.Point(351, 213);
            this.txtPageCount.Name = "txtPageCount";
            this.txtPageCount.Size = new System.Drawing.Size(115, 26);
            this.txtPageCount.TabIndex = 10;
            this.txtPageCount.Text = "200";
            // 
            // lblFullProgress
            // 
            this.lblFullProgress.AutoSize = true;
            this.lblFullProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFullProgress.Location = new System.Drawing.Point(56, 634);
            this.lblFullProgress.Name = "lblFullProgress";
            this.lblFullProgress.Size = new System.Drawing.Size(133, 29);
            this.lblFullProgress.TabIndex = 11;
            this.lblFullProgress.Text = "Progress :";
            // 
            // lblBookProgress
            // 
            this.lblBookProgress.AutoSize = true;
            this.lblBookProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookProgress.Location = new System.Drawing.Point(56, 585);
            this.lblBookProgress.Name = "lblBookProgress";
            this.lblBookProgress.Size = new System.Drawing.Size(133, 29);
            this.lblBookProgress.TabIndex = 12;
            this.lblBookProgress.Text = "Progress :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Root Download Path";
            // 
            // txtRootFolder
            // 
            this.txtRootFolder.Location = new System.Drawing.Point(275, 80);
            this.txtRootFolder.Name = "txtRootFolder";
            this.txtRootFolder.Size = new System.Drawing.Size(571, 26);
            this.txtRootFolder.TabIndex = 14;
            // 
            // lstBooks
            // 
            this.lstBooks.FormattingEnabled = true;
            this.lstBooks.ItemHeight = 20;
            this.lstBooks.Location = new System.Drawing.Point(27, 255);
            this.lstBooks.Name = "lstBooks";
            this.lstBooks.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstBooks.Size = new System.Drawing.Size(982, 244);
            this.lstBooks.TabIndex = 15;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(575, 214);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(125, 35);
            this.btnAdd.TabIndex = 16;
            this.btnAdd.Text = "Add Book";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(721, 214);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(125, 35);
            this.btnDelete.TabIndex = 17;
            this.btnDelete.Text = "Delete Book";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblTotalBooks
            // 
            this.lblTotalBooks.AutoSize = true;
            this.lblTotalBooks.Location = new System.Drawing.Point(834, 502);
            this.lblTotalBooks.Name = "lblTotalBooks";
            this.lblTotalBooks.Size = new System.Drawing.Size(101, 20);
            this.lblTotalBooks.TabIndex = 18;
            this.lblTotalBooks.Text = "Total Books :";
            // 
            // btnImageDownload
            // 
            this.btnImageDownload.Location = new System.Drawing.Point(481, 523);
            this.btnImageDownload.Name = "btnImageDownload";
            this.btnImageDownload.Size = new System.Drawing.Size(212, 35);
            this.btnImageDownload.TabIndex = 19;
            this.btnImageDownload.Text = "Start Image Download";
            this.btnImageDownload.UseVisualStyleBackColor = true;
            this.btnImageDownload.Click += new System.EventHandler(this.btnImageDownload_Click);
            // 
            // chkAuto
            // 
            this.chkAuto.AutoSize = true;
            this.chkAuto.Location = new System.Drawing.Point(721, 169);
            this.chkAuto.Name = "chkAuto";
            this.chkAuto.Size = new System.Drawing.Size(201, 24);
            this.chkAuto.TabIndex = 20;
            this.chkAuto.Text = "Auto Populate Book Url";
            this.chkAuto.UseVisualStyleBackColor = true;
            this.chkAuto.CheckedChanged += new System.EventHandler(this.chkAuto_CheckedChanged);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(868, 214);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(125, 35);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "Clear Book";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(781, 562);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(212, 35);
            this.button1.TabIndex = 22;
            this.button1.Text = "Rename Folders";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1346, 698);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.chkAuto);
            this.Controls.Add(this.btnImageDownload);
            this.Controls.Add(this.lblTotalBooks);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lstBooks);
            this.Controls.Add(this.txtRootFolder);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblBookProgress);
            this.Controls.Add(this.lblFullProgress);
            this.Controls.Add(this.txtPageCount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtFolderName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBookUrl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtHomeUrl);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnDownload);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "Mag Automation";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtHomeUrl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBookUrl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFolderName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPageCount;
        private System.Windows.Forms.Label lblFullProgress;
        private System.Windows.Forms.Label lblBookProgress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtRootFolder;
        private System.Windows.Forms.ListBox lstBooks;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblTotalBooks;
        private System.Windows.Forms.Button btnImageDownload;
        private System.Windows.Forms.CheckBox chkAuto;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button button1;
    }
}


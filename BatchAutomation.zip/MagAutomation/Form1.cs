﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using WK.Libraries.SharpClipboardNS;

namespace MagAutomation
{
    public partial class Form1 : Form
    {
        private IWebDriver _webDriver;
        private WebDriverWait wait;
        private int totalPages = 0;
        private int currentPage = 0;
        private string currentFolderName = string.Empty;
        private int totalDownloads = 0;
        private int downloadedFiles = 0;
        private List<string> downloadList;
        private int totalBooks = 0;
        private int currentBook = 0;
        private int downloadedBooks = 0;
        private SharpClipboard clipboard;

        public Form1()
        {
            InitializeComponent();
            clipboard = new SharpClipboard();
            clipboard.ClipboardChanged += Clipboard_ClipboardChanged;
            _webDriver = new ChromeDriver(AppDomain.CurrentDomain.BaseDirectory);
            downloadList = new List<string>();
        }

        private void Clipboard_ClipboardChanged(object sender, SharpClipboard.ClipboardChangedEventArgs e)
        {
            if (!chkAuto.Checked)
                return;

            // Is the content copied of text type?
            if (e.ContentType == SharpClipboard.ContentTypes.Text)
            {
                // Get the cut/copied text.
                Debug.WriteLine(clipboard.ClipboardText);

                if (!string.IsNullOrEmpty(clipboard.ClipboardText))
                {
                    string[] links;

                    if (clipboard.ClipboardText.Contains(Environment.NewLine))
                    {
                        links = clipboard.ClipboardText.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                    }
                    else
                    {
                        links = clipboard.ClipboardText.Split(new[] { "http" }, StringSplitOptions.RemoveEmptyEntries);
                    }

                    if (links.Count() > 0)
                    {
                        foreach (string link in links)
                        {
                            string url = link;
                            if (url.Contains("thumb") || url.Contains("ico"))
                                continue;

                            if (!url.Contains("http"))
                            {
                                url = "http" + url;
                            }

                            string booklink = url + "|" + string.Empty + "|" + txtPageCount.Text.Trim();

                            if (!lstBooks.Items.Contains(booklink))
                            {
                                lstBooks.Items.Add(booklink);
                            }

                            lblTotalBooks.Text = "Total Books : " + lstBooks.Items.Count.ToString();
                        }
                    }
                }


            }

            // Is the content copied of image type?
            else if (e.ContentType == SharpClipboard.ContentTypes.Image)
            {
                // Get the cut/copied image.
                Image img = clipboard.ClipboardImage;
            }

            // Is the content copied of file type?
            else if (e.ContentType == SharpClipboard.ContentTypes.Files)
            {
                // Get the cut/copied file/files.
                Debug.WriteLine(clipboard.ClipboardFiles.ToArray());

                // ...or use 'ClipboardFile' to get a single copied file.
                Debug.WriteLine(clipboard.ClipboardFile);
            }

            // If the cut/copied content is complex, use 'Other'.
            else if (e.ContentType == SharpClipboard.ContentTypes.Other)
            {
                // Do something with 'clipboard.ClipboardObject' or 'e.Content' here...
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblTotalBooks.Text = string.Empty;
            lblFullProgress.Text = string.Empty;
            lblBookProgress.Text = string.Empty;
            currentFolderName = string.Empty;
            downloadList = new List<string>();
            lstBooks.Items.Clear();
            totalPages = 0;
            currentPage = 0;
            totalDownloads = 0;
            downloadedFiles = 0;
            //driver.Url = "https://reader.magzter.com/reader/2ey54l1je6t89ysvglleir68162816589589/681628";
        }

        private bool CheckLinkAlreadyExists(string url)
        {
            return lstBooks.Items.Contains(url);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtHomeUrl.Text.Trim()))
            {
                MessageBox.Show("Provide Home URL", "Warning");
                return;
            }

            _webDriver.Navigate().GoToUrl(txtHomeUrl.Text.Trim());
        }

        private async void btnDownload_Click(object sender, EventArgs e)
        {
            if (lstBooks.Items.Count == 0)
            {
                MessageBox.Show("Provide add Book urls", "Warning");
                return;
            }

            if (txtRootFolder.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Provide provide Root Download Path", "Warning");
                return;
            }

            chkAuto.Checked = false;

            totalBooks = lstBooks.Items.Count;
            downloadedBooks = 0;

            foreach (string bookurl in lstBooks.Items)
            {
                lblBookProgress.Text = "Progress : " + downloadedBooks.ToString() + " Of " + totalBooks.ToString() + " Downloaded";

                string[] currentUrl = bookurl.Split('|');

                currentFolderName = currentUrl[1];
                totalPages = Convert.ToInt32(currentUrl[2]);
                currentPage = 0;
                downloadList.Clear();

                _webDriver.Navigate().GoToUrl(currentUrl[0]);

                Thread.Sleep(4000);

                if (currentFolderName == string.Empty)
                {
                    IWebElement magDate = this._webDriver.FindElement(By.ClassName("mgD__issue__dates"));
                    string tempFolderName = magDate.Text;
                    currentFolderName = GetFolderName(tempFolderName);
                }

                IWebElement button = this._webDriver.FindElement(By.ClassName("magzter__buttonText"));
                button.Click();

                wait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(30));
                wait.Until((x) =>
                {
                    return ((IJavaScriptExecutor)_webDriver).ExecuteScript("return document.readyState").Equals("complete");
                });

                Thread.Sleep(7000);

                if (_webDriver.WindowHandles.Count > 1)
                {
                    var newWindowHandle = _webDriver.WindowHandles[1];

                    if (!string.IsNullOrEmpty(newWindowHandle))
                    {
                        _webDriver.SwitchTo().Window(newWindowHandle);
                    }

                    string url = this._webDriver.Url;
                    string lastPageURL = string.Empty;

                    for (int i = 0; i <= totalPages; i++)
                    {
                        currentPage = i;

                        if (i != 0)
                        {
                            _webDriver.Navigate().GoToUrl(url + "#page/" + currentPage.ToString());
                        }

                        wait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(30));
                        wait.Until((x) =>
                        {
                            return ((IJavaScriptExecutor)_webDriver).ExecuteScript("return document.readyState").Equals("complete");
                        });

                        Thread.Sleep(4000);

                        if (lastPageURL != _webDriver.Url)
                            lastPageURL = _webDriver.Url;
                        else
                            break;

                        string html = this._webDriver.PageSource;
                        IList<IWebElement> elements = _webDriver.FindElements(By.ClassName("mainsvg"));

                        foreach (IWebElement webElement in elements)
                        {
                            if (!downloadList.Contains(webElement.GetAttribute("src")))
                            {
                                downloadList.Add(webElement.GetAttribute("src"));
                            }
                        }

                        i = i + 1;
                        currentPage = i;
                    }

                    _webDriver.Close();
                    _webDriver.SwitchTo().Window(_webDriver.WindowHandles[0]);

                    await DownloadFiles();

                    downloadedBooks = downloadedBooks + 1;
                }
                else
                {
                    continue;
                }

            }

        }

        private async Task DownloadFiles()
        {
            if (downloadList.Count == 0)
            {
                MessageBox.Show("Download links are empty", "Warning");
                return;
            }

            totalDownloads = downloadList.Count;
            downloadedFiles = 0;

            lblFullProgress.Text = "Progress : " + downloadedFiles.ToString() + " Of " + totalDownloads.ToString() + " Downloaded";

            using (WebClient wc = new WebClient())
            {
                wc.DownloadFileCompleted += Wc_DownloadFileCompleted;
                foreach (string url in downloadList)
                {
                    Uri uri = new Uri(url);
                    string filename = System.IO.Path.GetFileName(uri.LocalPath);
                    string orgFilename = System.IO.Path.GetFileName(uri.LocalPath);
                    string[] splits = url.Split('/');

                    if (filename.Contains(".jpg") || filename.Contains(".jpeg") || filename.Contains(".JPG"))
                    {
                        //No change
                    }
                    else
                    {
                        filename = splits[splits.Length - 2].ToString() + "-" + filename;
                    }

                    if (!Directory.Exists(txtRootFolder.Text.Trim() + "\\" + currentFolderName))
                    {
                        Directory.CreateDirectory(txtRootFolder.Text.Trim() + "\\" + currentFolderName);
                    }

                    if (File.Exists(txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + filename))
                    {
                        File.Delete(txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + filename);
                    }

                    Task task = wc.DownloadFileTaskAsync(
                        // Param1 = Link of file
                        new System.Uri(url),
                        // Param2 = Path to save
                        txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + filename);

                    await task;

                    if (filename.Contains("svg"))
                    {
                        if (File.Exists(txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + filename))
                        {
                            XDocument doc = XDocument.Load(txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + filename);
                            XElement rootElements = doc.Root;
                            IEnumerable<XElement> nodes = from element1 in rootElements.Elements("{http://www.w3.org/2000/svg}defs") select element1;
                            IEnumerable<XElement> childNodes = from element2 in nodes.Elements("{http://www.w3.org/2000/svg}image") select element2;
                            XElement xElement = childNodes.FirstOrDefault();                            

                            foreach (XElement element in childNodes)
                            {
                                string imageName = element.LastAttribute.Value;

                                if (imageName.IndexOfAny(Path.GetInvalidFileNameChars()) < 0)
                                {
                                    string svgImage = url.Replace(orgFilename, imageName);

                                    if (imageName == "image1.png")
                                    {
                                        imageName = Path.GetFileNameWithoutExtension(filename) + ".png";
                                    }

                                    if (File.Exists(txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + imageName))
                                    {
                                        File.Delete(txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + imageName);
                                    }

                                    using (WebClient wcsvgimage = new WebClient())
                                    {
                                        Task task1 = wcsvgimage.DownloadFileTaskAsync(
                                    // Param1 = Link of file
                                    new System.Uri(svgImage),
                                    // Param2 = Path to save
                                    txtRootFolder.Text.Trim() + "\\" + currentFolderName + "\\" + imageName);
                                        await task1;
                                    }
                                }

                            }
                        }
                    }

                }

            }
        }

        private void Wc_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            downloadedFiles = downloadedFiles + 1;
            lblFullProgress.Text = "Progress : " + downloadedFiles.ToString() + " Of " + totalDownloads.ToString() + " Downloaded";
            lblBookProgress.Text = "Progress : " + downloadedBooks.ToString() + " Of " + totalBooks.ToString() + " Downloaded";
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            if (lstBooks.Items.Count == 0)
            {
                MessageBox.Show("Provide add Book urls", "Warning");
                return;
            }

            if (txtRootFolder.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Provide provide Root Download Path", "Warning");
                return;
            }

            chkAuto.Checked = false;

            totalBooks = lstBooks.Items.Count;
            downloadedBooks = 0;

            foreach (string bookurl in lstBooks.Items)
            {
                lblBookProgress.Text = "Progress : " + downloadedBooks.ToString() + " Of " + totalBooks.ToString() + " Downloaded";

                string[] currentUrl = bookurl.Split('|');

                currentFolderName = currentUrl[1];

                _webDriver.Navigate().GoToUrl(currentUrl[0]);

                Thread.Sleep(4000);

                if (currentFolderName == string.Empty)
                {
                    IWebElement magDate = this._webDriver.FindElement(By.ClassName("mgD__issue__dates"));
                    string tempFolderName = magDate.Text;
                    currentFolderName = GetFolderName(tempFolderName);
                }

                string[] dirs = Directory.GetDirectories(txtRootFolder.Text.Trim());

                foreach (string dir in dirs)
                {
                    DirectoryInfo directoryInfo = new DirectoryInfo(dir);
                    string fromFolder = directoryInfo.FullName;
                    string toFolder = directoryInfo.Parent.FullName;
                    if (dir.Contains(_webDriver.Url.Split('/').Last()))
                    {
                        toFolder = Path.Combine(toFolder, currentFolderName);
                        Directory.Move(fromFolder, toFolder);
                        break;
                    }
                }

                downloadedBooks = downloadedBooks + 1;
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtHomeUrl.Text.Trim()))
            {
                MessageBox.Show("Provide Book Home Page", "Warning");
                return;
            }

            //if (string.IsNullOrEmpty(txtFolderName.Text.Trim()))
            //{
            //    MessageBox.Show("Provide Book folder name", "Warning");
            //    return;
            //}

            if (string.IsNullOrEmpty(txtPageCount.Text.Trim()))
            {
                MessageBox.Show("Provide Book no of pages", "Warning");
                return;
            }

            string booklink = txtBookUrl.Text.Trim() + "|" + txtFolderName.Text.Trim() + "|" + txtPageCount.Text.Trim();

            if (!lstBooks.Items.Contains(booklink))
            {
                lstBooks.Items.Add(booklink);
            }

            lblTotalBooks.Text = "Total Books : " + lstBooks.Items.Count.ToString();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lstBooks.SelectedIndex != -1)
            {
                foreach (string s in lstBooks.SelectedItems.OfType<string>().ToList())
                    lstBooks.Items.Remove(s);
            }

            lblTotalBooks.Text = "Total Books : " + lstBooks.Items.Count.ToString();
        }

        private async void btnImageDownload_Click(object sender, EventArgs e)
        {
            if (lstBooks.Items.Count == 0)
            {
                MessageBox.Show("Provide add Book urls", "Warning");
                return;
            }

            if (txtRootFolder.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Provide provide Root Download Path", "Warning");
                return;
            }

            chkAuto.Checked = false;

            totalBooks = lstBooks.Items.Count;
            downloadedBooks = 0;

            foreach (string bookurl in lstBooks.Items)
            {
                lblBookProgress.Text = "Progress : " + downloadedBooks.ToString() + " Of " + totalBooks.ToString() + " Downloaded";

                string[] currentUrl = bookurl.Split('|');

                currentFolderName = currentUrl[1];
                totalPages = Convert.ToInt32(currentUrl[2]);
                currentPage = 0;
                downloadList.Clear();

                _webDriver.Navigate().GoToUrl(currentUrl[0]);

                Thread.Sleep(4000);

                if (currentFolderName == string.Empty)
                {
                    IWebElement magDate = this._webDriver.FindElement(By.ClassName("mgD__issue__dates"));
                    string tempFolderName = magDate.Text;
                    currentFolderName = GetFolderName(tempFolderName);
                }

                IWebElement button = this._webDriver.FindElement(By.ClassName("magzter__buttonText"));
                button.Click();

                wait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(30));
                wait.Until((x) =>
                {
                    return ((IJavaScriptExecutor)_webDriver).ExecuteScript("return document.readyState").Equals("complete");
                });

                Thread.Sleep(7000);

                if (_webDriver.WindowHandles.Count > 1)
                {
                    var newWindowHandle = _webDriver.WindowHandles[1];

                    if (!string.IsNullOrEmpty(newWindowHandle))
                    {
                        _webDriver.SwitchTo().Window(newWindowHandle);
                    }

                    string url = this._webDriver.Url;

                    Thread.Sleep(4000);

                    string html = this._webDriver.PageSource;
                    IList<IWebElement> elements = _webDriver.FindElements(By.TagName("img"));

                    foreach (IWebElement webElement in elements)
                    {
                        if (webElement.GetAttribute("src").Contains("thumb"))
                            continue;

                        if (!downloadList.Contains(webElement.GetAttribute("src")))
                        {
                            downloadList.Add(webElement.GetAttribute("src"));
                        }
                    }

                    if (downloadList.Count > 0)
                    {
                        string tempImageUrl = downloadList[0].ToString();
                        Uri uri = new Uri(tempImageUrl);
                        string filename = System.IO.Path.GetFileName(uri.LocalPath);
                        tempImageUrl = tempImageUrl.Replace(filename, "");

                        for (int i = 1; i <= totalPages; i++)
                        {
                            if (!downloadList.Contains(tempImageUrl + i.ToString() + ".jpg"))
                            {
                                downloadList.Add(tempImageUrl + i.ToString() + ".jpg");
                            }
                        }
                    }

                    _webDriver.Close();
                    _webDriver.SwitchTo().Window(_webDriver.WindowHandles[0]);

                    await DownloadFiles();

                    downloadedBooks = downloadedBooks + 1;
                }
                else
                {
                    continue;
                }

            }
        }

        private string GetFolderName(string name)
        {
            string tempFolderName = name;
            tempFolderName = tempFolderName.Replace("- ", "");
            tempFolderName = tempFolderName.Replace(" - ", "").Replace(",", " ");
            tempFolderName = tempFolderName.Replace(", ", " ");
            tempFolderName = tempFolderName.Replace(" ", "-");
            tempFolderName = tempFolderName.Replace("--", "-").Replace("--", "-");

            if (tempFolderName.Contains("January"))
            {
                tempFolderName = tempFolderName.Replace("January", "Jan");
            }
            else if (tempFolderName.Contains("February"))
            {
                tempFolderName = tempFolderName.Replace("February", "Feb");
            }
            else if (tempFolderName.Contains("March"))
            {
                tempFolderName = tempFolderName.Replace("March", "Mar");
            }
            else if (tempFolderName.Contains("April"))
            {
                tempFolderName = tempFolderName.Replace("April", "Apr");
            }
            else if (tempFolderName.Contains("May"))
            {
                tempFolderName = tempFolderName.Replace("May", "May");
            }
            else if (tempFolderName.Contains("June"))
            {
                tempFolderName = tempFolderName.Replace("June", "Jun");
            }
            else if (tempFolderName.Contains("July"))
            {
                tempFolderName = tempFolderName.Replace("July", "Jul");
            }
            else if (tempFolderName.Contains("August"))
            {
                tempFolderName = tempFolderName.Replace("August", "Aug");
            }
            else if (tempFolderName.Contains("September"))
            {
                tempFolderName = tempFolderName.Replace("September", "Sep");
            }
            else if (tempFolderName.Contains("October"))
            {
                tempFolderName = tempFolderName.Replace("October", "Oct");
            }
            else if (tempFolderName.Contains("November"))
            {
                tempFolderName = tempFolderName.Replace("November", "Nov");
            }
            else if (tempFolderName.Contains("December"))
            {
                tempFolderName = tempFolderName.Replace("December", "Dec");
            }

            return tempFolderName;
        }

        private void chkAuto_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstBooks.Items.Clear();
            lblTotalBooks.Text = "Total Books : " + lstBooks.Items.Count.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XDocument doc = XDocument.Load(txtRootFolder.Text.Trim());
            XElement rootElements = doc.Root;
            IEnumerable<XElement> nodes = from element1 in rootElements.Elements("{http://www.w3.org/2000/svg}defs") select element1;
            IEnumerable<XElement> childNodes = from element2 in nodes.Elements("{http://www.w3.org/2000/svg}image") select element2;
            XElement xElement = childNodes.FirstOrDefault();

            
            
        }
    }
}

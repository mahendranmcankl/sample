﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BatchAutomation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBatchFile.Text.Trim()))
            {
                MessageBox.Show("Provide batch file!", "Warning");
                return;
            }

            if (string.IsNullOrEmpty(txtRootFolder.Text.Trim()))
            {
                MessageBox.Show("Provide root folder!", "Warning");
                return;
            }

            string[] dirs;

            dirs = Directory.GetDirectories(txtRootFolder.Text.Trim());

            foreach (string dir in dirs)
            {
                if (Directory.Exists(Path.Combine(dir, "out")))
                    continue;

                if (!File.Exists(Path.Combine(dir, Path.GetFileName(txtBatchFile.Text.Trim()))))
                {
                    File.Copy(txtBatchFile.Text.Trim(), Path.Combine(dir, Path.GetFileName(txtBatchFile.Text.Trim())));
                }

                int ExitCode;
                ProcessStartInfo ProcessInfo;
                Process process;

                ProcessInfo = new ProcessStartInfo(Path.Combine(dir, Path.GetFileName(txtBatchFile.Text.Trim())));
                ProcessInfo.CreateNoWindow = false;
                ProcessInfo.UseShellExecute = false;
                ProcessInfo.WorkingDirectory = Path.GetDirectoryName(Path.Combine(dir, Path.GetFileName(txtBatchFile.Text.Trim())));
                ProcessInfo.RedirectStandardError = true;
                ProcessInfo.RedirectStandardOutput = true;

                process = Process.Start(ProcessInfo);
                process.WaitForExit();

                ExitCode = process.ExitCode;
                process.Close();
            }
        }
    }
}

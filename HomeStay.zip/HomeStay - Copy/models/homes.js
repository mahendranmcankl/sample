const homes =  [{
	home: '1BHK',
	image: 'https://s8.postimg.org/wbpizc0c5/image1.jpg',
	city : 'Bangalore',
	area: '400 Sq. Ft',
	averageprice: '13750/Sq.Ft',
	totalprice: 5500000,
	emi: '12000'
},
{
	home: '2BHK',
	image: 'https://s31.postimg.org/4v98as857/image2.jpg',
	city : 'Bangalore',
	area: '550 Sq. Ft',
	averageprice: '58330/Sq.Ft',
	totalprice: 17500000,
	emi: '51000'
},

{
	home: '1BHK',
	image: 'https://s18.postimg.org/55afxswyx/image3.jpg',
	city : 'Bangalore',
	area: '600 Sq. Ft',
	averageprice: '8572/Sq.Ft',
	totalprice: 6000000,
	emi: '9000'
},

{
	home: '2BHK',
	image: 'https://s28.postimg.org/ai2jqjpul/image4.jpg',
	city : 'Bangalore',
	area: '700 Sq. Ft',
	averageprice: '13334/Sq.Ft',
	totalprice: 9000000,
	emi: '15000'
},

{
	home: '1BHK',
	image: 'https://s31.postimg.org/m2bsm2yez/image5.jpg',
	city : 'Bangalore',
	area: '60 Sq. Mtr',
	averageprice: '60000/Sq. Mtr',
	totalprice: 4800000,
	emi: '20000'
},

{
	home: '1BHK',
	image: 'https://s17.postimg.org/ljgucn3kv/image6.jpg',
	city : 'Delhi',
	area: '160 Sq. Yards',
	averageprice: '36038/Sq. Yards',
	totalprice: 5766000,
	emi: '22500'
},

{
	home: '1BHK',
	image: 'https://s8.postimg.org/wbpizc0c5/image1.jpg',
	city : 'Delhi',
	area: '533 Sq. Ft',
	averageprice: '2814/Sq. Ft',
	totalprice: 1500000,
	emi: '5000'
},
{
	home: '1BHK',
	image: 'https://s18.postimg.org/55afxswyx/image3.jpg',
	city : 'Delhi',
	area: '900 Sq. Yards',
	averageprice: '5000/Sq. Yards',
	totalprice: 4500000,
	emi: '11000'
},

{
	home: '2BHK',
	image: 'https://s31.postimg.org/4v98as857/image2.jpg',
	city : 'Delhi',
	area: '682 Sq. Ft',
	averageprice: '4202/Sq. Ft',
	totalprice: 2866000,
	emi: '15000'
},

{
	home: '1BHK',
	image: 'https://s31.postimg.org/m2bsm2yez/image5.jpg',
	city : 'Delhi',
	area: '1200 Sq. Ft',
	averageprice: '11066/Sq. Ft',
	totalprice: 8300000,
	emi: '15000'
}];

module.exports = homes;
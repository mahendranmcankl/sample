var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var schema = new Schema({
    home: {type: String, required: true},
    image: {type: String, required: true},
    city: {type: String, required: true},
    area: {type: String, required: true},
    averageprice: {type: String, required: true},
    totalprice: {type: Number, required: true},
    emi: {type: String, required: true}
});

module.exports = mongoose.model('HomeSchema', schema);
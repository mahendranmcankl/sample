var express = require('express');
var router = express.Router();

const statichomes = require("../models/homes");
const HomeSchema = require( "../models/home" );

router.get('/', function (req, res, next) {

    HomeSchema.find({}, function(err, homes) {
        
        if( homes.length<1 ){
            
            HomeSchema.collection.insert(statichomes, function callback(error, insertedDocs) {
                
                HomeSchema.find({ 'home':req.query.home, 'city':req.query.city, 'totalprice': { $gt: req.query.minBudget, $lt: req.query.maxBudget } }, function(err, homes) {
                    if(homes && Array.isArray(homes)){
                        if(homes.length > 0){
                            res.json({status: "success", data: homes || statichomes});
                        }
                        else {
                            res.json({status:"info", message:"no data found"});
                        }
                     }
                     
                     else{
                         res.json({status:"failure", message:"could not read the homes data"});
                     }
                });

            });
        }
        else{
            
            HomeSchema.find({ 'home':req.query.home, 'city':req.query.city, 'totalprice': { $gt: req.query.minBudget, $lt: req.query.maxBudget } }, function(err, homes) {
                if(homes && Array.isArray(homes)){
                    
                    if(homes.length > 0){
                        res.json({status: "success", data: homes || statichomes});
                    }
                    else {
                        res.json({status:"info", message:"no data found"});
                    }
                 }
                 
                 else{
                     res.json({status:"failure", message:"could not read the homes data"});
                 }
            });
        }

    });

});

router.post('/', function (req, res, next) {
    console.log(req.body);
     if(homes && Array.isArray(homes)){

        if(homes.length > 0){
            res.json({status: "success", data: homes});
        }
        else {
            res.json({status:"info", message:"no data found"});
        }
     }
     
     else{
         res.json({status:"failure", message:"could not read "});
     }

});
module.exports = router;

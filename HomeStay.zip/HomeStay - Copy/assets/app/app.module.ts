import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpModule } from "@angular/http";

import { AppComponent } from "./app.component";
import { HomeComponent } from './home/home.component';
import { DataService } from './home/data.service';
import { ResultsComponent } from './results/results.component'
import { routing } from "./app.routing";

@NgModule({
    declarations: [
        AppComponent,
        HomeComponent,
        ResultsComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        routing,
        ReactiveFormsModule,
        HttpModule
    ],
    providers: [DataService],
    bootstrap: [AppComponent]
})
export class AppModule {

}
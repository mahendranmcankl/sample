import { Component } from '@angular/core';
import { DataService } from './data.service';
import {Router} from '@angular/router';

@Component({
    selector: 'my-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent {


	// initiate dataservice and router
	constructor( public dataSvc : DataService , public router : Router){

	}


	// Error keys object to show different kind of errors and info to user
	errorKeys = {
		isCityValid : true,
		isBhkValid : true,
		isMinBudgetValid: true,
		isMaxBudgetValid: true,
		isMaxLessThanMinValid: true,
		isNoResultValid : true
	}

	// property to store/fetch the list of homes
	homes;

	// call this function when you click on view properties button
	// call "this.validateForm" function from here and if it returns true make http request
	// using function of dataService 
	// if homes list if fetched successfully, store it in dataService and navigate to results page
	onSubmit(form){
		console.log(form);
		
		//TODO1
		//1. Validate form

		//2. If form gets validated, make call data service functions to fetch data
		
		//3. When request is successful, set the list of properties inside a property of “data service” and using router navigate to “results" route

		if(this.validateForm(form))
		{
			this.dataSvc.getHomes(form)
			.subscribe(result => {
				this.homes = result.data

				if(this.homes != undefined && this.homes.length > 0)
				{
					this.dataSvc.setHomesData(this.homes);
				
					// Navigate to results page
					this.router.navigate(['/results']);
				}
				else
				{
					this.errorKeys.isNoResultValid=false;
				}
				
			});
		}

	}

	// call this function from "onSubmit" function to validate if form is valid or not
	// do all validations from here and show and hide the error messages in UI
	// return false if form is invalid, return true if form is valid
	validateForm( form ){
		this.errorKeys = {
			isCityValid : true,
			isBhkValid : true,
			isMinBudgetValid: true,
			isMaxBudgetValid: true,
			isMaxLessThanMinValid: true,
			isNoResultValid : true
		}

		//TODO2
		//1. do all validations and return false if there is any error
		//2. set error key to true according to the invalid field

		if(form.city=="")
		{
			this.errorKeys.isCityValid=false;
		}
		if(form.home=="")
		{
			this.errorKeys.isBhkValid=false;
		}
		if(form.maxBudget.toString().length==0)
		{
			this.errorKeys.isMaxBudgetValid=false;
		}
		if(form.minBudget.toString().length==0)
		{
			this.errorKeys.isMinBudgetValid=false;
		}

		if(form.minBudget<0 || form.minBudget > 10000000000)
		{
			this.errorKeys.isMinBudgetValid=false;
		}
		
		if(form.maxBudget<0 || form.maxBudget > 10000000000)
		{
			this.errorKeys.isMaxBudgetValid=false;
		}		

		if(this.errorKeys.isMinBudgetValid==true && this.errorKeys.isMaxBudgetValid==true)
		{
			if(form.minBudget > form.maxBudget)
			{
				this.errorKeys.isMaxLessThanMinValid=false;
			}
		}

		if(this.errorKeys.isCityValid==false 
			|| this.errorKeys.isBhkValid==false
			|| this.errorKeys.isMaxBudgetValid==false
			|| this.errorKeys.isMinBudgetValid==false
			|| this.errorKeys.isMaxLessThanMinValid==false)
			{
				return false;
			}
			else
			{
				return true;
			}

		// else return true

		// else{
		// 	return true;
		// }

	}

}
## Angular Reactive forms

This is a demo project repository for [Angular Reactive forms blog](https://medium.com/aviabird/complete-angular2-guide-reactive-forms-in-depth-part-1-21a8e2428904).

Concept for this form is directly picked from our startup [Yatrum](http://yatrum.com) an application for travellers. Code for it is also open source and can be found [here](https://github.com/aviabird/yatrum). Go ahead clone it and use it for your purpose in any way you want.

## Development server
Commands to run the example locally.

* `npm install`
* `ng serve`
 
Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Deploying to Github Pages

Run `ng github-pages:deploy` to deploy to Github Pages.

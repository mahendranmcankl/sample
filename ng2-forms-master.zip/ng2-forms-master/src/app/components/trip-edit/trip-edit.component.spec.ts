/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TripEditComponent } from './trip-edit.component';

describe('Component: TripEdit', () => {
  it('should create an instance', () => {
    let component = new TripEditComponent();
    expect(component).toBeTruthy();
  });
});

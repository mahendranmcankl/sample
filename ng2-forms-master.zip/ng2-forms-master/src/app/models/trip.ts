import { City } from './city';

export class Trip {
    name: string;
    cities: City[];
}
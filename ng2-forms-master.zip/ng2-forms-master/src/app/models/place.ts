export class Place {
    name: string;
}
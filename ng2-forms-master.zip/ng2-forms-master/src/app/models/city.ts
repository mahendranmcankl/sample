import { Place } from './place';

export class City {
    name: string;
    places: Place[];
}
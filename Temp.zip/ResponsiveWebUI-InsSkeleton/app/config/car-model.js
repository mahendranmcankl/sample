const carModel = [
	{
		"manufacturer": "maruti",
		"models": [
			"Zen",
			"A-Star",
			"Ritz",
			"Swift",
			"Baleno"
		]
	},
	{
		"manufacturer": "tata",
		"models": [
			"Nano",
			"Indica",
			"Indigo Manza",
			"Sumo",
			"Safari"
		]
	},
	{
		"manufacturer": "ford",
		"models": [
			"Ikon",
			"Fiesta"
		]
	},
	{
		"manufacturer": "honda",
		"models": [
			"City",
			"Civic",
			"Accord"
		]
	}
];

module.exports = carModel;
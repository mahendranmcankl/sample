const carFuelType =  ["petrol", "diesel"];

module.exports = carFuelType;
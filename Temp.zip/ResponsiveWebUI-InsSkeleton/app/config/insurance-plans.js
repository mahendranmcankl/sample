var insurancePlan = [
    {
        "name": "HDFC ERGO",
        "price": 80000
    },
    {
        "name": "Bajaj Allianz",
        "price": 12500
    },
    {
        "name": "Reliance Insurance",
        "price": 76000
    },
    {
        "name": "New Indian",
        "price": 56000
    }
]

module.exports = insurancePlan;

var helpers = {
    // This is the place for all the helper functions.

    PopulateSelect: function (data, elementId, defaultOptionName) {
        if (!data || !data[0]) {
            return;
        }

        $("#" + elementId).empty();

        var select = document.getElementById(elementId);
        var defaultoption = document.createElement('option');
        defaultoption.value = "0";
        defaultoption.label = " Select a " + defaultOptionName;
        select.appendChild(defaultoption);

        for (var i = 0; i < data.length; i++) {
            var option = document.createElement('option');
            option.value = data[i];
            option.label = data[i];
            select.appendChild(option);
        }
    },

    AjaxCall: function (url, method, data, callback) {
        $.ajax({
            method: method,
            data: data,
            url: url,
            success: function (resp, status) {
                callback(resp.data);
            }
        });
    }
};

// Handle all the logics once the document is ready
$(document).ready(function () {
    // here you need to handle and implement all the logics for new insurance and renew insurance requirements.
    // Try to leverange the power of jQuery to do the DOM manipulation to achieve the requirements.
    // id "#insurance" in index.html should load the insurance template on DOM ready

    // Load Insurance page
    $("#insurance").load('./views/insurance.html', function () {
        $("#divDropdownFields").hide();
        $("#divEntryFields").hide();
        $("#divBuyInsurance").hide();

        $("#rdoGetNew").click(function () {
            $("#divDropdownFields").show();
            $("#divEntryFields").show();
            $("#divBuyInsurance").hide();
            ClearFields();

            // Get Car Type
            var carTypesCallback = function (data) {
                helpers.PopulateSelect(data, "ddCarType", "car type");
            };

            helpers.AjaxCall('http://localhost:3000/api/common/getCarModels', "GET", "", carTypesCallback);

            // Get Fuel Type
            var fuelTypeCallback = function (data) {
                helpers.PopulateSelect(data, "ddFuelType", "fuel type");
            };

            helpers.AjaxCall('http://localhost:3000/api/common/getFuelType', "GET", "", fuelTypeCallback);

            // Get Registration State
            var regStateCallback = function (data) {
                helpers.PopulateSelect(data, "ddRegistrationState", "state");
            };

            helpers.AjaxCall('http://localhost:3000/api/common/getRegStateCodes', "GET", "", regStateCallback);
        });

        $("#btnGetQuotes").click(function () {
            if (ValidateNewInsuranceFields()) {
                $("#divDropdownFields").hide();
                $("#divEntryFields").hide();
                $("#divBuyInsurance").show();

                // Get Quotes
                var getQuoteCallback = function (data) {

                    if (data != undefined) {
                        var count = $('#right .box-item').length;
                        $.each(data, function (index, data) {

                            var content = "<div itemid='itm-'" + (count + 1) + " class='btn btn-default box-item'>" + data.name + " <br> " + "Price - " + data.price + "</div>"
                            $('#left').append(content);
                        })
                    }

                    $('.box-item').draggable({
                        cursor: 'move',
                        helper: "clone"
                    });
                };

                $("#btnBuyInsurance").click(function () {
                    if (localStorage.getItem("selectedPlan") != undefined) {

                        var carType = $('#ddCarType').val();
                        var fuelType = $('#ddFuelType').val();
                        var registrationState = $('#ddRegistrationState').val();
                        var userName = $('#txtUserName').val();
                        var phoneNumber = $('#txtPhoneNumber').val();
                        var selectedPlan = JSON.parse(localStorage.getItem("selectedPlan"));

                        var addInsuranceData = {
                            "userName": userName,
                            "phoneNumber": phoneNumber,
                            "carType": carType,
                            "fuelType": fuelType,
                            "registrationState": registrationState,
                            "plan": {
                                "name": selectedPlan.name,
                                "price": selectedPlan.price
                            }
                        };

                        // Get Quotes
                        var addInsuranceCallback = function (data) {

                            if (data != undefined) {
                                var successMessage = "You have successfully bought the insurance. Your policy number is " + data.policyNumber;
                                $("#SuccessMessage").empty();
                                $("#SuccessMessage").append(successMessage);

                                $("#dialog-message").dialog({
                                    closeOnEscape: false,
                                    modal: true,
                                    open: function(event, ui) {
                                        $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
                                    },                                
                                    buttons: {
                                        Ok: function () {
                                            $(this).dialog("close");
                                            $('#left').empty();
                                            $('#right').empty();
                                            $("#divDropdownFields").hide();
                                            $("#divEntryFields").hide();
                                            $("#divBuyInsurance").hide();
                                            $("#rdoGetNew").prop('checked', false);
                                        }
                                    }
                                });
                            }
                            else {
                                var successMessage = "An error occured. Please try again." + data.policyNumber;
                                $("#SuccessMessage").empty();
                                $("#SuccessMessage").append(successMessage);                                

                                $("#dialog-message").dialog({
                                    closeOnEscape: false,
                                    modal: true,
                                    open: function(event, ui) {
                                        $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
                                    },                                
                                    buttons: {
                                        Ok: function () {
                                            $(this).dialog("close");
                                            $('#left').empty();
                                            $('#right').empty();
                                            $("#divDropdownFields").hide();
                                            $("#divEntryFields").hide();
                                            $("#divBuyInsurance").hide();
                                            $("#rdoGetNew").prop('checked', false);
                                        }
                                    }
                                });
                            }
                        };

                        helpers.AjaxCall('http://localhost:3000/api/addInsurance', "POST", addInsuranceData, addInsuranceCallback);
                    }
                });

                helpers.AjaxCall('http://localhost:3000/api/getQuotes', "GET", "", getQuoteCallback);
            }
        });

        $("#left").droppable({
            drop: function (event, ui) {
                var item = $(ui.draggable);
                $('#left').append(item);

                if (localStorage.getItem("selectedPlan") != undefined) {
                    localStorage.removeItem("selectedPlan");
                }
            }
        });

        $("#right").droppable({
            drop: function (event, ui) {
                var item = $(ui.draggable);
                if ($('#right .box-item').length == 0) {
                    $('#right').append(item);

                    var itemSplit = item.html().split(" <br> " + "Price - ");

                    var selectedPlan = { "name": itemSplit[0], "price": itemSplit[1] };

                    localStorage.setItem("selectedPlan", JSON.stringify(selectedPlan));
                }
            }
        });

    });

    function ClearFields() {
        $(".error").remove();
        $('#left').empty();
        $('#right').empty();
        $('#txtUserName').val('');
        $('#txtPhoneNumber').val('');
    }

    function ValidateNewInsuranceFields() {
        var valid = true;
        $(".error").remove();

        var carType = $('#ddCarType').val();
        var fuelType = $('#ddFuelType').val();
        var registrationState = $('#ddRegistrationState').val();
        var userName = $('#txtUserName').val();
        var phoneNumber = $('#txtPhoneNumber').val();

        if (carType.length < 1 || carType == "0") {
            $('#ddCarType').after('<span class="error"><br>Please select a Car Type</span>');
            valid = false;
        }

        if (fuelType.length < 1 || fuelType == "0") {
            $('#ddFuelType').after('<span class="error"><br>Please select a Fuel Type</span>');
            valid = false;
        }

        if (registrationState.length < 1 || registrationState == "0") {
            $('#ddRegistrationState').after('<span class="error"><br>Please select a Registration State</span>');
            valid = false;
        }

        if (userName.length < 1) {
            $('#txtUserName').after('<span class="error"><br>User Name is required</span>');
            valid = false;
        }
        else if (userName.length < 2 || userName.length > 50) {
            $('#txtUserName').after('<span class="error"><br>Please enter a valid user name</span>');
            valid = false;
        }

        if (phoneNumber.length < 1) {
            $('#txtPhoneNumber').after('<span class="error"><br>Phone Number is required</span>');
            valid = false;
        }
        else {
            intRegex = /[0-9]+$/;

            if ((phoneNumber.length != 10) || (!intRegex.test(phoneNumber))) {
                $('#txtPhoneNumber').after('<span class="error"><br>Please enter a valid phone number</span>');
                valid = false;
            }
        }

        return valid;
    }


});


